
/**
 * section 2, drop down sections
 */

import React, { useState,useRef,useEffect } from "react";
import './index.css'
import background2 from '../../assert/background2.webp'

import Popup from 'reactjs-popup'

const Index = ({}) => {
    const [OurCoursesMouseIn, setOurCoursesMouseIn] = useState(false)

    return(
        <div className={'Section2-container'}>
            <div className={'Section2-buttonGap'} />
            {/* ------------------------------------------------------------ Our courses */}
            <Popup
                trigger={
                    <div className={OurCoursesMouseIn?'Section2-button-movein':'Button-moveout'}> Our Courses </div>
                }
                position="bottom left"
                on="hover"
                onOpen={()=>setOurCoursesMouseIn(true)}
                onClose={()=>setOurCoursesMouseIn(false)}
                closeOnDocumentClick
                mouseLeaveDelay={300}
                mouseEnterDelay={0}
                contentStyle={{ padding: '0px', border: 'none' }}
                arrow={false}
            >
                <div className="menu">
                    <div className="menu-item"> item 1</div>
                    <div className="menu-item"> item 2</div>
                    <div className="menu-item"> item 3</div>
                </div>
            </Popup>
        </div>
    )
}
  
export default Index;

const DropDownList = ({options}) =>(
    <Popup
        trigger={<div className="menu-item"> Sub menu </div>}
        position="right top"
        on="hover"
        closeOnDocumentClick
        mouseLeaveDelay={300}
        mouseEnterDelay={0}
        contentStyle={{ padding: '0px', border: 'none' }}
        arrow={false}
    >
        <div className="menu">
            <div className="menu-item"> item 1</div>
            <div className="menu-item"> item 2</div>
            <div className="menu-item"> item 3</div>
        </div>
    </Popup>
)

