import React, { useState,useRef,useEffect } from "react";
import './index.css'

import Header from './Header'
import Section1 from './Section1'
import Section2 from './Section2'

const Index = (props) => {

    return(
        <div className={'home-container'}>
            <Header />
            <Section1 />
            <Section2 />
        </div>
    )
}
  
export default Index;
